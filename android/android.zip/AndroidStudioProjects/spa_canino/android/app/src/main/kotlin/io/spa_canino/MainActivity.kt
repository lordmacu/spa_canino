package io.spa_canino

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
